import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'question-add-update',
  templateUrl: './questionAddUpdate.html'
})
export class questionAddUpdateComponent implements OnInit {
  private quesCat: any = "3";
  private multi: Array<any> = [];
  private question: any = {

  };
  // multiSelect: [''],
  // category: ""

  profileForm = new FormGroup({
    questionCategory: new FormControl(''),
    questionType: new FormControl(''),
    question: new FormControl(''),
    description: new FormControl(''),
    multipleSelectOption: new FormControl(''),
  });

  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.warn(this.profileForm.value);
    console.log('question obj ::', this.question);
  }

  subjectiveFlag: boolean;
  singleSelectFlag: boolean;
  multipleSelectFlag: boolean;
  multipleSelectEdit: boolean;
  singleSelectEdit: boolean;

  singleSelectCount: number;
  multipleSelectCount: number;

  multipleSelectoptionArray = [];
  singleSelectoptionArray = [];

  constructor(private toastr: ToastrService) { }

  ngOnInit() {
    this.disbleAllFlag();
    this.singleSelectCount = 2;
    this.multipleSelectCount = 2;
    this.multipleSelectEdit = false;
    this.singleSelectEdit = false;
  }

  disbleAllFlag() {
    this.subjectiveFlag = false;
    this.singleSelectFlag = false;
    this.multipleSelectFlag = false;
  }

  addSubstractMultipleSelectOptions(actionType) {
    this.multipleSelectEdit = true;
    console.log("before question :: ", this.question);



    if (actionType == 'add') {
      if (this.multipleSelectCount >= 5) {
        this.toastr.warning('Can add only Max 5 Options');
      }
      else {
        this.multipleSelectCount++;
        this.multipleSelectoptionArray.push(this.multipleSelectCount);
      }
    }


    // if (actionType == 'add') {
    //   if (this.multipleSelectCount >= 5) {
    //     this.toastr.warning('Can add only Max 5 Options');
    //   }
    //   else {
    //     this.multipleSelectCount++;
    //     this.multipleSelectoptionArray.push("");
    //     console.log("after question :: ", this.question);
    //   }
    // }
    if (actionType == 'sub') {
      if (this.multipleSelectCount <= 2) {
        this.toastr.warning('Min 2 Options are Mandatory');
      }
      else {
        this.multipleSelectCount--;
        this.question.pop();
      }
    }
  }


  addSubstractSingleSelectOptions(actionType) {
    this.singleSelectEdit = true;

    if (actionType == 'add') {
      if (this.singleSelectCount >= 5) {
        this.toastr.warning('Can add only Max 5 Options');
      }
      else {
        this.singleSelectCount++;
        this.singleSelectoptionArray.push(this.singleSelectCount);
      }
    }
    if (actionType == 'sub') {
      if (this.singleSelectCount <= 2) {
        this.toastr.warning('Min 2 Options are Mandatory');
      }
      else {
        this.singleSelectCount--;
        this.singleSelectoptionArray.pop();
      }
    }
  }

  loadOptions(questionTypeValue) {
    if (questionTypeValue == "multipleSelect") {
      this.disbleAllFlag();
      this.multipleSelectFlag = true;
      if (this.multipleSelectEdit === false) {
        for (var i = 1; i <= this.multipleSelectCount; i++) {
          this.multipleSelectoptionArray.push(i);
        }
        this.multipleSelectEdit = true;
      }
    }
    if (questionTypeValue == "SingleSelect") {
      this.disbleAllFlag();
      this.singleSelectFlag = true;
      if (this.singleSelectEdit === false) {
        for (var i = 1; i <= this.singleSelectCount; i++) {
          this.singleSelectoptionArray.push(i);
        }
        this.singleSelectEdit = true;
      }
    }
    if (questionTypeValue == "subjective") {
      this.disbleAllFlag();
      this.subjectiveFlag = true;
    }

  }

  // multimodelChanged(e, i) {
  //   console.log("i :: ", i);

  //   console.log("e :: ", e);
  //   this.question[i] = e.target.value;
  //   if (i == 0) {
  //     //this.question["multiSelect"][i+1] = "";
  //   }

  //   console.log("question :: ", this.question);
  // }
}
